"use strict";
cc._RF.push(module, 'a5a2f/VdqRNG6x3e3MFpiZ8', 'mainMenu');
// scripts/mainMenu.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        global_manager_prefab: {
            type: cc.Prefab,
            default: null
        },
        round_start_btn: {
            type: cc.Node,
            default: null
        },
        game_end_btn: {
            type: cc.Node,
            default: null
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        if (!cc.find('global_manager')) {
            var scene = cc.director.getScene();
            var global_manager = cc.instantiate(this.global_manager_prefab);
            global_manager.parent = scene;
        }
        this.global_manager = cc.find('global_manager');
        var global_manager_script = 'global_manager';

        var eventHandler_roundStart = new cc.Component.EventHandler();
        eventHandler_roundStart.target = this.global_manager;
        eventHandler_roundStart.component = global_manager_script;
        eventHandler_roundStart.handler = 'load_choose';
        this.round_start_btn.getComponent(cc.Button).clickEvents.push(eventHandler_roundStart);

        var eventHandler_gameEnd = new cc.Component.EventHandler();
        eventHandler_gameEnd.target = this.global_manager;
        eventHandler_gameEnd.component = global_manager_script;
        eventHandler_gameEnd.handler = 'game_end';
        this.game_end_btn.getComponent(cc.Button).clickEvents.push(eventHandler_gameEnd);

        cc.director.preloadScene(this.global_manager.getComponent(global_manager_script).levelScenes[0]);
        // console.log();
    }
}

// start () {},

// update (dt) {},
);

cc._RF.pop();