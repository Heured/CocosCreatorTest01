"use strict";
cc._RF.push(module, '3dd8cUygRVPlrCC50FXqLmd', 'buttons');
// scripts/buttons.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        round_reload_button: {
            type: cc.Node,
            default: null
        },
        round_choose_button: {
            type: cc.Node,
            default: null
        },
        global_manager: {
            type: cc.Node,
            default: null
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        // 获取管理器节点
        this.global_manager = cc.find('global_manager');
        var global_manager_script = 'global_manager';

        var eventHandler_choose = new cc.Component.EventHandler();
        eventHandler_choose.target = this.global_manager;
        eventHandler_choose.component = global_manager_script;
        eventHandler_choose.handler = 'load_choose';

        var eventHandler_restart = new cc.Component.EventHandler();
        eventHandler_restart.target = this.global_manager;
        eventHandler_restart.component = global_manager_script;
        eventHandler_restart.handler = 'round_start';

        // 绑定选关按钮触发事件
        this.round_reload_button.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = '重来';
        this.round_reload_button.getComponent(cc.Button).clickEvents.push(eventHandler_restart);

        // 绑定重来按钮触发时间
        this.round_choose_button.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = '选关';
        this.round_choose_button.getComponent(cc.Button).clickEvents.push(eventHandler_choose);
    }
}

// update (dt) {},
);

cc._RF.pop();