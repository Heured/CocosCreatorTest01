"use strict";
cc._RF.push(module, 'c5465rEKflIl6EsDqyWDLcT', 'global_manager');
// scripts/global_manager.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        levelScenes: {
            default: [],
            type: [cc.String]
        },
        levelCoin: {
            default: [],
            type: [cc.Integer]
        },
        levelUnlock: {
            default: [],
            type: [cc.Boolean]
        },
        mainMenu: '',
        chooseScene: '',
        levelNow: 0,
        roundEnd: {
            default: null,
            type: cc.Prefab
        },
        audio_click: {
            type: cc.AudioClip,
            default: null
        },
        audio_music: {
            type: cc.AudioClip,
            default: null
        },
        audio_round_pass: {
            type: cc.AudioClip,
            default: null
        },
        audio_round_failed: {
            type: cc.AudioClip,
            default: null
        },
        round_end_status: false

    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        cc.game.addPersistRootNode(this.node);
        this.levelScenes = ['Map_00', 'Map_01', 'Map_02'];
        this.levelCoin = [6, 7, 7];
        this.levelUnlock = [true, false, false];
        this.mainMenu = 'MainMenu';
        this.chooseScene = 'ChooseMenu';
        cc.audioEngine.play(this.audio_music, true, 0.3);
    },


    // 加载场景
    round_start: function round_start() {
        this.round_end_status = false;
        cc.audioEngine.play(this.audio_click, false, 1);
        cc.director.loadScene(this.levelScenes[this.levelNow]);
    },

    // 执行过关逻辑
    round_pass: function round_pass() {
        if (this.round_end_status) return;
        this.round_end_status = true;

        cc.audioEngine.playEffect(this.audio_round_pass, false);
        this.levelNow++;
        var global_manager = this.node;
        var global_manager_script = 'global_manager';

        var eventHandler_left = new cc.Component.EventHandler();
        eventHandler_left.target = global_manager;
        eventHandler_left.component = global_manager_script;

        var eventHandler_right = new cc.Component.EventHandler();
        eventHandler_right.target = global_manager;
        eventHandler_right.component = global_manager_script;

        var node = cc.instantiate(this.roundEnd);
        node.parent = cc.find('Canvas');
        if (this.levelNow == this.levelUnlock.length) {
            var main_label = node.children[1].getComponent(cc.Label);
            var left_button = node.children[2];
            var right_button = node.children[3];

            main_label.string = '你通关了';

            // 绑定选关按钮触发事件
            left_button.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = '选关';
            eventHandler_left.handler = 'load_choose';
            left_button.getComponent(cc.Button).clickEvents.push(eventHandler_left);

            // 绑定主菜单按钮触发时间
            right_button.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = '主菜单';
            eventHandler_right.handler = 'load_main';
            right_button.getComponent(cc.Button).clickEvents.push(eventHandler_right);
        } else {
            // 解锁关卡
            this.levelUnlock[this.levelNow] = true;

            var _main_label = node.children[1].getComponent(cc.Label);
            var _left_button = node.children[2];
            var _right_button = node.children[3];

            _main_label.string = '过关了';

            // 绑定选关按钮触发事件
            _left_button.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = '选关';
            eventHandler_left.handler = 'load_choose';
            _left_button.getComponent(cc.Button).clickEvents.push(eventHandler_left);

            // 绑定主菜单按钮触发时间
            _right_button.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = '下一关';
            eventHandler_right.handler = 'round_start';
            _right_button.getComponent(cc.Button).clickEvents.push(eventHandler_right);
        }

        // 移动到屏幕中间
        node.runAction(cc.moveTo(1, cc.v2(0, 0)));
    },

    //执行失败逻辑
    round_failed: function round_failed() {
        if (this.round_end_status) return;
        this.round_end_status = true;

        cc.audioEngine.playEffect(this.audio_round_failed, false);
        var global_manager = this.node;
        var global_manager_script = 'global_manager';

        var eventHandler_left = new cc.Component.EventHandler();
        eventHandler_left.target = global_manager;
        eventHandler_left.component = global_manager_script;
        eventHandler_left.handler = 'load_choose';

        var eventHandler_right = new cc.Component.EventHandler();
        eventHandler_right.target = global_manager;
        eventHandler_right.component = global_manager_script;
        eventHandler_right.handler = 'round_start';

        // 创建关卡结束界面
        var node = cc.instantiate(this.roundEnd);
        node.parent = cc.find('Canvas');

        var main_label = node.children[1].getComponent(cc.Label);
        var left_button = node.children[2];
        var right_button = node.children[3];

        main_label.string = '还差一点';

        // 绑定选关按钮触发事件
        left_button.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = '选关';
        left_button.getComponent(cc.Button).clickEvents.push(eventHandler_left);

        // 绑定重来按钮触发时间
        right_button.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = '重来';
        right_button.getComponent(cc.Button).clickEvents.push(eventHandler_right);

        // 移动到屏幕中间
        node.runAction(cc.moveTo(1, cc.v2(0, 0)));
    },

    // 加载选关场景
    load_choose: function load_choose() {
        this.round_end_status = false;
        cc.audioEngine.play(this.audio_click, false, 1);
        cc.director.loadScene(this.chooseScene);
    },

    // 加载主菜单页面
    load_main: function load_main() {
        cc.audioEngine.play(this.audio_click, false, 1);
        cc.director.loadScene(this.mainMenu);
    },

    // 关卡选择
    round_choose: function round_choose(event, customEventData) {
        cc.audioEngine.play(this.audio_click, false, 1);
        this.levelNow = parseInt(customEventData);
        cc.director.loadScene(this.levelScenes[this.levelNow]);
    },

    // 关卡结束逻辑
    round_end: function round_end(player_dead) {
        if (player_dead) {
            this.round_failed();
        } else {
            this.round_pass();
        }
    },

    // 退出游戏
    game_end: function game_end() {
        cc.audioEngine.play(this.audio_click, false, 1);
        cc.game.end();
    }

    // start () {},

    // update (dt) {},
});

cc._RF.pop();