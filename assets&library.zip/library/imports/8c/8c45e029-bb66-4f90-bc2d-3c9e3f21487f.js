"use strict";
cc._RF.push(module, '8c45eApu2ZPkLwtPJ4/IUh/', 'monster_ctrl');
// scripts/monster_ctrl.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        move_speed: 25,
        monster_type: 1, //1:可被炸弹炸飞； 2:不会碰到炸弹，不会被迷晕； 3：不会碰到炸弹，会被迷晕；
        toward: 200,
        directionX: 0,
        duration: 7,
        dizzying: false,
        bullets: {
            type: cc.Prefab,
            default: null
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        // 获取刚体以及碰撞体
        this.rbody = this.getComponent(cc.RigidBody);
        // this.phy_collider = this.getComponent(cc.PhysicsBoxCollider);
        //记录初始X轴位置
        this.firstX = this.node.x;
    },

    // 开始运动
    _onMove: function _onMove() {
        this.directionX = 1;
        var v = this.rbody.linearVelocity;
        v.x = this.move_speed;
        this.rbody.linearVelocity = v;
    },
    // 被炸飞
    _blowAway: function _blowAway() {
        var v = this.rbody.linearVelocity;
        v.x *= -4;
        v.y = 400;
        this.rbody.linearVelocity = v;
        var rot = cc.rotateBy(2, 720);
        var vanish = cc.callFunc(function () {
            this.node.destroy();
        }, this);
        this.node.runAction(cc.sequence(rot, vanish));
    },
    // 回头
    _turnBack: function _turnBack() {
        this.directionX *= -1;
        this.node.scaleX *= -1;
        var v = this.rbody.linearVelocity;
        v.x *= -1;
        this.rbody.linearVelocity = v;
        this.scheduleOnce(this._turnBack.bind(this), this.duration);
    },
    // 眩晕
    _ondizzy: function _ondizzy() {
        var dizzy_anim = this.node.getComponent(cc.Animation);
        dizzy_anim.play('fly_enemy_hit');
        this.dizzying = true;
        this.scheduleOnce(function () {
            var normal_anim = this.node.getComponent(cc.Animation);
            normal_anim.play('fly_enemy_move');
            this.dizzying = false;
        }.bind(this), 3);
    },
    // 攻击
    _onAttack: function _onAttack() {
        // 播放攻击动画
        var attack_anim = this.node.getComponent(cc.Animation);
        attack_anim.play('bullet_enemy_attack');

        // 动画播放完发射子弹
        this.scheduleOnce(function () {
            // 生成子弹
            var bullets = cc.instantiate(this.bullets);
            bullets.parent = this.node.parent;
            bullets.position = this.node.position;
            bullets.x += this.directionX * 30;
            bullets.y += 10;
            bullets.scaleX = this.node.scaleX;
            var v = this.rbody.linearVelocity;
            v.x *= 4;
            bullets.getComponent(cc.RigidBody).linearVelocity = v;
            // 5秒后子弹销毁
            this.scheduleOnce(bullets.destroy.bind(bullets), 5);
            // 播放运动动画
            var normal_anim = this.node.getComponent(cc.Animation);
            normal_anim.play('bullet_enemy_move');
            // 预定下一次攻击
            var time = Math.random() * 3 + 3;
            this.scheduleOnce(this._onAttack.bind(this), time);
        }.bind(this), 1.3);
    },
    onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
        // 类型1小怪碰到炸弹，炸弹爆炸，小怪被炸飞
        if (otherCollider.tag == 6 && this.monster_type == 1) this._blowAway();
        // 类型3小怪碰到加了buff的玩家，进入眩晕状态
        if (otherCollider.tag == 0 && this.monster_type == 3) if (otherCollider.node.getComponent('player_ctrl').buffing && !this.dizzying) this._ondizzy();
    },
    start: function start() {
        this._onMove();
        this.scheduleOnce(this._turnBack.bind(this), this.duration);
        if (this.monster_type == 2) this._onAttack();
    }
}

// update (dt) {
// console.log(this.rbody.linearVelocity.x);
// },
);

cc._RF.pop();