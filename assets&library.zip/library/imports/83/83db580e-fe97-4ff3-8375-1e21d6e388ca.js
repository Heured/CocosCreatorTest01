"use strict";
cc._RF.push(module, '83db5gO/pdP84N1HiHW44jK', 'player_ctrl');
// scripts/player_ctrl.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        runSpeed: 25,
        runDamp: 25,
        maxSpeed: cc.v2(250, 250),
        directionX: 0,
        directionY: 0,
        jumpSpeed: 500,
        jumping: false,
        running: false,
        climbable: false,
        climbing: false,
        buffing: false,
        dead: false,
        touching_ladder: {
            type: cc.PhysicsBoxCollider,
            default: null
        },
        coin_count: {
            type: cc.Node,
            default: null
        },
        bomb_prefab: {
            type: cc.Prefab,
            default: null
        },
        buff_prefab: {
            type: cc.Prefab,
            default: null
        },
        audio_jump: {
            type: cc.AudioClip,
            default: null
        },
        audio_dead: {
            type: cc.AudioClip,
            default: null
        },
        audio_coin: {
            type: cc.AudioClip,
            default: null
        },
        audio_buff: {
            type: cc.AudioClip,
            default: null
        }

    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        //打开键盘事件监听
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyPressed, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyReleased, this);

        // 定义接触物体数
        this.touchingNumber = 0;

        // 获取刚体以及碰撞体
        this.rbody = this.getComponent(cc.RigidBody);
        this.phy_collider = this.getComponent(cc.PhysicsBoxCollider);

        //获取dragonBones动画播放组件
        this._armatureDisplay = this.getComponent(dragonBones.ArmatureDisplay);
    },


    //跳跃动作
    _jump: function _jump() {
        if (this.jumping) return;
        cc.audioEngine.play(this.audio_jump, false, 1);
        this.jumping = true;
        this.directionY = 1;
        this._armatureDisplay.playAnimation('Jump', 0);
    },

    //奔跑动作
    _run: function _run() {
        if (this.running) return;
        this.running = true;
        this._armatureDisplay.playAnimation('Run', 0);
    },

    //发呆动作
    _idle: function _idle() {
        if (this.jumping) return;
        this.running = false;
        this._armatureDisplay.playAnimation('Idle', 0);
    },

    //攀爬动作
    _onClimb: function _onClimb() {
        if (!this.climbable) return;

        //修改传感器属性为真，刷新碰撞体，进入传感器状态。
        this.phy_collider.sensor = true;
        this.phy_collider.apply();

        //状态以及速度初始化
        this.jumping = false;
        this.running = false;
        this.directionX = 0;
        this.rbody.linearVelocity = cc.v2(0, 0);

        //关闭重力
        this.rbody.gravityScale = 0;

        //修正角色位置
        var ladder_aabb = this.touching_ladder.getAABB();
        var pos_to = ladder_aabb.x + ladder_aabb.width / 2;
        pos_to = this.node.parent.convertToNodeSpaceAR(cc.v2(pos_to, 0));
        this.node.x = pos_to.x;

        //进入攀爬状态，打开攀爬动画
        this.climbing = true;
        this._armatureDisplay.playAnimation('Climb', 0);
    },

    //取消攀爬
    _offClimb: function _offClimb() {

        //退出攀爬状态，打开发呆动画
        this.climbing = false;
        this._armatureDisplay.playAnimation('Idle', 0);

        //初始化速度
        this.directionY = 0;
        this.rbody.linearVelocity = cc.v2(0, 1);

        //打开重力
        this.rbody.gravityScale = 5;

        //修改传感器属性为假，刷新碰撞体，进入刚体状态。
        this.phy_collider.sensor = false;
        this.phy_collider.apply();
    },

    // 角色死亡
    _die: function _die() {
        cc.audioEngine.play(this.audio_dead, false, 1);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyPressed, this);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyReleased, this);
        this.dead = true;
        this.directionX = 0;
        this.scheduleOnce(function () {
            this._armatureDisplay.playAnimation('Die', 1);
        }, 0.1);
    },

    // 安置炸弹
    _dropBomb: function _dropBomb() {
        var bomb = cc.instantiate(this.bomb_prefab);
        bomb.parent = cc.find('Canvas/root');
        bomb.position = this.node.position;
    },

    // 加上植株buff
    _addBuff: function _addBuff() {
        cc.audioEngine.play(this.audio_buff, false, 1);
        var buff = cc.instantiate(this.buff_prefab);
        buff.parent = this.node;
        buff.position = cc.v2(0, 0);
        buff.getComponent(cc.Animation).play();
        this.buffing = true;

        // buff持续时间为7秒
        this.scheduleOnce(function () {
            var buff = this.node.children[0];
            this.buffing = false;
            buff.destroy();
        }.bind(this), 7);
    },

    onKeyPressed: function onKeyPressed(event) {
        var keyCode = event.keyCode;
        if (!this.climbing) {
            switch (keyCode) {
                case cc.macro.KEY.a:
                case cc.macro.KEY.left:
                    this.directionX = -1;
                    if (!this.jumping) this._run();
                    break;
                case cc.macro.KEY.d:
                case cc.macro.KEY.right:
                    this.directionX = 1;
                    if (!this.jumping) this._run();
                    break;
                case cc.macro.KEY.w:
                case cc.macro.KEY.up:
                    if (this.climbable) {
                        this._onClimb();
                    } else this._jump();
                    break;
                case cc.macro.KEY.space:
                    this._dropBomb();
                    break;
            }
        } else {
            switch (keyCode) {
                case cc.macro.KEY.w:
                case cc.macro.KEY.up:
                    this.directionY = -1;
                    break;
                case cc.macro.KEY.s:
                case cc.macro.KEY.down:
                    this._offClimb();
                    break;
            }
        }
        // 查看角色当前状态
        // switch(keyCode){
        //     case cc.macro.KEY.e:
        //         console.log('jumping',this.jumping,'running',this.running);
        //         console.log('climbable',this.climbable,'climbing',this.climbing);
        //         console.log('dirX',this.directionX,'dirY',this.directionY);
        //         console.log('vX',this.rbody.linearVelocity.x,'vY',this.rbody.linearVelocity.y);
        //         console.log('touching',this.touchingNumber);
        //         break;
        //     case cc.macro.KEY.q:
        //         cc.director.loadScene('MainMenu');
        // }
    },

    onKeyReleased: function onKeyReleased(event) {
        var keyCode = event.keyCode;
        if (!this.climbing) {
            switch (keyCode) {
                case cc.macro.KEY.a:
                case cc.macro.KEY.left:
                    if (this.directionX == -1) {
                        this.directionX = 0;
                        this._idle();
                    }
                    break;
                case cc.macro.KEY.d:
                case cc.macro.KEY.right:
                    if (this.directionX == 1) {
                        this.directionX = 0;
                        this._idle();
                    }
                    break;
            }
        } else {
            switch (keyCode) {
                case cc.macro.KEY.w:
                case cc.macro.KEY.up:
                    this.directionY = 0;
                    this.rbody.linearVelocity = cc.v2(0, 0);
                    break;
            }
        }
    },

    //碰撞开始
    onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
        this.touchingNumber++;

        switch (otherCollider.tag) {
            case 0:
            case 5:
                //当你在下落时碰到平台类或箱子类碰撞体恢复发呆动画
                if (this.rbody.linearVelocity.y < 0 && !this.dead) {
                    this.jumping = false;
                    this._idle();
                    if (this.directionX != 0) this._run();
                }
                break;
            case 2:
                //碰到梯子，进入可攀爬状态
                this.climbable = true;
                //标记梯子
                this.touching_ladder = otherCollider;
                break;
            case 3:
                // 碰到可伤害角色的物体
                var monster_script = otherCollider.node.getComponent('monster_ctrl');
                // 碰到类型3小怪，如果角色在buff状态或者小怪在眩晕状态，角色不会死亡
                if (monster_script) if (this.buffing && monster_script.monster_type == 3 || monster_script.dizzying) break;

                if (!this.dead) {
                    this._die();
                    var global_manager = cc.find('global_manager');
                    var global_manager_script = global_manager.getComponent('global_manager');
                    global_manager_script.round_end(true);
                }
                break;
            case 4:
                // 碰到金币
                cc.audioEngine.play(this.audio_coin, false, 0.3);
                var coin_count_script = this.coin_count.getComponent('coin_count');
                otherCollider.node.destroy();
                coin_count_script.coin_add();
                break;
            case 7:
                // 碰到buff植株
                this._addBuff();
                otherCollider.node.destroy();
                break;
        }
    },

    //碰撞持续时 每次处理完碰撞体接触逻辑是被调用
    // onPostSolve: function (contact, selfCollider, otherCollider) {},

    //碰撞结束
    onEndContact: function onEndContact(contact, selfCollider, otherCollider) {
        this.touchingNumber--;

        //离开梯子，关闭可攀爬状态
        if (otherCollider.tag == 2) {
            this.climbable = false;
            if (this.climbing) {
                this.scheduleOnce(function () {
                    this._offClimb();
                }, 0.1);
            }
        }
    },

    updatePosition: function updatePosition() {
        //跳跃位移
        if (this.directionY == 1) {
            var v = this.rbody.linearVelocity;
            this.directionY = 0;
            v.y += this.jumpSpeed;
            this.rbody.linearVelocity = v;
        }

        //奔跑位移
        if (this.directionX != 0 && Math.abs(this.rbody.linearVelocity.x) < this.maxSpeed.x) {
            this.node.scaleX = -0.3 * this.directionX;

            var _v = this.rbody.linearVelocity;
            _v.x += this.directionX * this.runSpeed;
            this.rbody.linearVelocity = _v;
            //速度削减
        } else {
            var _v2 = this.rbody.linearVelocity;
            // if(v.x<0 && v.x != 0)
            if (_v2.x < 0) _v2.x += this.runDamp;

            // if(v.x>0 && v.x != 0)
            if (_v2.x > 0) _v2.x -= this.runDamp;

            if (!this.directionX && Math.abs(_v2.x) < 25) _v2.x = 0;
            // v.x = 0;
            this.rbody.linearVelocity = _v2;
        }

        //攀爬位移
        if (this.directionY == -1) {
            var _v3 = this.rbody.linearVelocity;
            _v3.x = 0;
            _v3.y = 50;
            this.rbody.linearVelocity = _v3;
        }

        // 没有接触任何碰撞，且在下落状态
        if (this.touchingNumber == 0 && this.rbody.linearVelocity.y < 0) {
            this.jumping = true;
        }
    },


    // start () {},

    update: function update(dt) {
        this.updatePosition();
    }
});

cc._RF.pop();