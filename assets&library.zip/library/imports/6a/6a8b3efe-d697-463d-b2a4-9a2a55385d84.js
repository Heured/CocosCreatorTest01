"use strict";
cc._RF.push(module, '6a8b37+1pdGPbKkmipVOF2E', 'coin_count');
// scripts/coin_count.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        target: 0,
        count: 0,
        target_label: {
            type: cc.Node,
            default: null
        },
        count_label: {
            type: cc.Node,
            default: null
        },
        global_manager: {
            type: cc.Node,
            default: null
        }

    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    start: function start() {
        // 获取管理器节点
        this.global_manager = cc.find('global_manager');
        var global_manager_script = this.global_manager.getComponent('global_manager');

        // 获取当前金币目标个数，初始化金币已得个数
        this.target = global_manager_script.levelCoin[global_manager_script.levelNow];
        this.count = 0;

        // 将以上获得的数据输出到界面计分标签
        var coinCountLabel = this.count_label.getComponent(cc.Label);
        var coinTargetLabel = this.target_label.getComponent(cc.Label);
        coinCountLabel.string = '0';
        coinTargetLabel.string = this.target.toString();
    },


    // 获取一个金币后计分相关逻辑
    coin_add: function coin_add() {
        var coinCountLabel = this.count_label.getComponent(cc.Label);
        this.count++;
        coinCountLabel.string = this.count.toString();

        // 金币数达到目标数
        if (this.count == this.target) {
            var global_manager_script = this.global_manager.getComponent('global_manager');
            //参数表示角色是否死亡
            global_manager_script.round_end(false);
        }
    }

    // update (dt) {},
});

cc._RF.pop();