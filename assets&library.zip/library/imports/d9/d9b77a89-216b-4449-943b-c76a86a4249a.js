"use strict";
cc._RF.push(module, 'd9b77qJIWtESZQ7x2qGpCSa', 'chooseMenu');
// scripts/chooseMenu.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        mainMenu_btn: {
            type: cc.Node,
            default: null
        },
        rounds: {
            type: cc.Node,
            default: null
        },
        global_manager: {
            type: cc.Node,
            default: null
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        // 获取管理器节点
        this.global_manager = cc.find('global_manager');
        var global_manager_script = 'global_manager';

        // 为主界面按钮添加点击事件
        var eventHandler_mainMenu = new cc.Component.EventHandler();
        eventHandler_mainMenu.target = this.global_manager;
        eventHandler_mainMenu.component = global_manager_script;
        eventHandler_mainMenu.handler = 'load_main';
        this.mainMenu_btn.getComponent(cc.Button).clickEvents.push(eventHandler_mainMenu);

        // 刷新当前关卡解锁状态
        var levelUnlock = this.global_manager.getComponent('global_manager').levelUnlock;
        for (var i in levelUnlock) {
            var thisChild = this.rounds.children[i];
            if (levelUnlock[i]) {
                // 显示数字而不显示锁
                thisChild.children[0].active = true;
                thisChild.children[1].active = false;

                // 给这个节点添加按钮组件
                var round_btn = thisChild.addComponent(cc.Button);

                var eventHandler_levelChoose = new cc.Component.EventHandler();
                eventHandler_levelChoose.target = this.global_manager;
                eventHandler_levelChoose.component = global_manager_script;
                eventHandler_levelChoose.handler = 'round_choose';
                eventHandler_levelChoose.customEventData = i.toString();
                round_btn.clickEvents.push(eventHandler_levelChoose);
            } else {
                // 显示数字而不显示锁
                thisChild.children[0].active = false;
                thisChild.children[1].active = true;
            }
        }
    }
}

// update (dt) {},
);

cc._RF.pop();