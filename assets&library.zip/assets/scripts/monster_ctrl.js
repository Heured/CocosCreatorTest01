cc.Class({
    extends: cc.Component,

    properties: {
        move_speed: 25,
        monster_type: 1,//1:可被炸弹炸飞； 2:不会碰到炸弹，不会被迷晕； 3：不会碰到炸弹，会被迷晕；
        toward: 200,
        directionX: 0,
        duration: 7,
        dizzying: false,
        bullets:{
            type:cc.Prefab,
            default: null,
        },
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        // 获取刚体以及碰撞体
        this.rbody = this.getComponent(cc.RigidBody);
        // this.phy_collider = this.getComponent(cc.PhysicsBoxCollider);
        //记录初始X轴位置
        this.firstX = this.node.x;


    },
    // 开始运动
    _onMove: function(){
        this.directionX = 1;
        let v = this.rbody.linearVelocity;
        v.x = this.move_speed;
        this.rbody.linearVelocity = v;
    },
    // 被炸飞
    _blowAway: function(){
        let v = this.rbody.linearVelocity;
        v.x *= -4;
        v.y = 400;
        this.rbody.linearVelocity = v;
        let rot = cc.rotateBy(2,720);
        let vanish = cc.callFunc(function(){
            this.node.destroy();
        },this);
        this.node.runAction(cc.sequence(rot,vanish));
    },
    // 回头
    _turnBack: function(){
        this.directionX *= -1;
        this.node.scaleX *= -1;
        let v = this.rbody.linearVelocity;
        v.x *= -1;
        this.rbody.linearVelocity = v;
        this.scheduleOnce(this._turnBack.bind(this),this.duration);
    },
    // 眩晕
    _ondizzy: function(){
        let dizzy_anim = this.node.getComponent(cc.Animation);
        dizzy_anim.play('fly_enemy_hit');
        this.dizzying = true;
        this.scheduleOnce(function(){
            let normal_anim = this.node.getComponent(cc.Animation);
            normal_anim.play('fly_enemy_move');
            this.dizzying = false;
        }.bind(this),3);
    },
    // 攻击
    _onAttack:function(){
        // 播放攻击动画
        let attack_anim = this.node.getComponent(cc.Animation);
        attack_anim.play('bullet_enemy_attack');

        // 动画播放完发射子弹
        this.scheduleOnce(function(){
            // 生成子弹
            let bullets = cc.instantiate(this.bullets);
            bullets.parent = this.node.parent;
            bullets.position = this.node.position;
            bullets.x += this.directionX * 30;
            bullets.y += 10;
            bullets.scaleX = this.node.scaleX;
            let v = this.rbody.linearVelocity;
            v.x *=4;
            bullets.getComponent(cc.RigidBody).linearVelocity = v;
            // 5秒后子弹销毁
            this.scheduleOnce(bullets.destroy.bind(bullets),5);
            // 播放运动动画
            let normal_anim = this.node.getComponent(cc.Animation);
            normal_anim.play('bullet_enemy_move');
            // 预定下一次攻击
            let time  = Math.random()*3 +3;
            this.scheduleOnce(this._onAttack.bind(this),time);
        }.bind(this),1.3);


        


    },
    onBeginContact: function (contact, selfCollider, otherCollider){
        // 类型1小怪碰到炸弹，炸弹爆炸，小怪被炸飞
        if(otherCollider.tag == 6 && this.monster_type == 1)
            this._blowAway();
        // 类型3小怪碰到加了buff的玩家，进入眩晕状态
        if(otherCollider.tag == 0 && this.monster_type == 3)
            if(otherCollider.node.getComponent('player_ctrl').buffing && !this.dizzying)
                this._ondizzy();
    },
    start () {
        this._onMove();
        this.scheduleOnce(this._turnBack.bind(this),this.duration);
        if(this.monster_type == 2)
            this._onAttack();
        
        

    },

    // update (dt) {
        // console.log(this.rbody.linearVelocity.x);
    // },
});
