cc.Class({
    extends: cc.Component,

    properties: {
        audio_explode:{
            type: cc.AudioClip,
            default: null,
        },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    // 炸弹爆炸
    explode: function(){
        cc.audioEngine.play(this.audio_explode, false, 0.3);
        let explode = this.node.getComponent(cc.Animation);
        explode.play();
    },
    // 5秒后自动消失
    disappear: function(){
        this.scheduleOnce(function(){
            this.node.destroy();
        },5);
    },
    // 碰到可伤害小怪，执行爆炸
    onBeginContact: function (contact, selfCollider, otherCollider){
        let monster_ctrl = otherCollider.node.getComponent('monster_ctrl');

        // 只有类型1的怪物会被炸飞
        if(monster_ctrl)
            if(otherCollider.tag == 3 && monster_ctrl.monster_type == 1)
                this.explode();
    },
    start () {
        this.disappear();

    },

    // update (dt) {},
});
