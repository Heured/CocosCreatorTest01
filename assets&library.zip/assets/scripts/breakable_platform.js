cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.phy_collider = this.node.getComponent(cc.PhysicsBoxCollider);

    },
    onBeginContact: function(contact,selfCollider,otherCollider){
        // 当玩家下落到可破坏平台0.5秒后，可破坏平台会变为没有支撑状态。再过3秒回到有支撑状态。
        if(selfCollider.sensor==false && otherCollider.node.getComponent(cc.RigidBody).linearVelocity.y<0){
            this.scheduleOnce(function(){
                this.node.opacity = 125;
                this.phy_collider.sensor = true;
                this.phy_collider.apply();

                this.scheduleOnce(function(){
                    this.node.opacity = 255;
                    this.phy_collider.sensor = false;
                    this.phy_collider.apply();
                }.bind(this),3);
            }.bind(this),0.5);
        }
    },

    // start () {},

    // update (dt) {},
});
