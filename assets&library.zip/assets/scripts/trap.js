cc.Class({
    extends: cc.Component,

    properties: {
        duration: 3,
        up: 120,
        down: -150,
        audio_activate:{
            type:cc.AudioClip,
            default: null,
        },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    _trap_activate: function(){
        // 播放陷阱启动动画
        let anim = this.node.getComponent(cc.Animation);
        anim.play();
        // 改变物理碰撞体位置
        let phy_collider = this.node.getComponent(cc.PhysicsBoxCollider);
        phy_collider.offset = cc.v2(80,this.up);
        phy_collider.apply();

        cc.audioEngine.play(this.audio_activate,false,0.3);

        // 动画播放周期为1.1秒，所以设置1.1秒后，将物理碰撞体归位，等待3秒后重新回调陷阱触发方法。
        this.scheduleOnce(function(){
            let phy_collider = this.node.getComponent(cc.PhysicsBoxCollider);
            phy_collider.offset = cc.v2(80,this.down);
            phy_collider.apply();
            this.scheduleOnce(this._trap_activate.bind(this),this.duration);
        }.bind(this),1.1)

    
    },
    start () {
        this._trap_activate();
    },

    // update (dt) {},
});
