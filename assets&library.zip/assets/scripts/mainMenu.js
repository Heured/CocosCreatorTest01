cc.Class({
    extends: cc.Component,

    properties: {
        global_manager_prefab:{
            type: cc.Prefab,
            default: null,
        },
        round_start_btn:{
            type: cc.Node,
            default: null,
        },
        game_end_btn:{
            type: cc.Node,
            default: null,
        },
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        if(!cc.find('global_manager')){
            let scene = cc.director.getScene();
            let global_manager = cc.instantiate(this.global_manager_prefab);
            global_manager.parent = scene;
        }
        this.global_manager = cc.find('global_manager');
        let global_manager_script = 'global_manager';

        let eventHandler_roundStart = new cc.Component.EventHandler();
        eventHandler_roundStart.target = this.global_manager;
        eventHandler_roundStart.component = global_manager_script;
        eventHandler_roundStart.handler = 'load_choose';
        this.round_start_btn.getComponent(cc.Button).clickEvents.push(eventHandler_roundStart);

        let eventHandler_gameEnd = new cc.Component.EventHandler();
        eventHandler_gameEnd.target = this.global_manager;
        eventHandler_gameEnd.component = global_manager_script;
        eventHandler_gameEnd.handler = 'game_end';
        this.game_end_btn.getComponent(cc.Button).clickEvents.push(eventHandler_gameEnd);

        cc.director.preloadScene(this.global_manager.getComponent(global_manager_script).levelScenes[0]);
        // console.log();

    },

    // start () {},

    // update (dt) {},
});
