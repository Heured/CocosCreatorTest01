<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Tileset_Rock" tilewidth="512" tileheight="512" tilecount="256" columns="16">
 <image source="Tileset_Rock.png" width="8192" height="8192"/>
</tileset>
